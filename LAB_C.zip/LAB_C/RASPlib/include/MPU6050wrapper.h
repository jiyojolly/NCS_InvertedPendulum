

void MPU6050Accel_Init(void);
void MPU6050Accel_Read(int* pfData);
void MPU6050Gyro_Init(int DLPFmode);
void MPU6050Gyro_Read(int* pfData);
void MPU6050Temp_Read(int* pfData);
