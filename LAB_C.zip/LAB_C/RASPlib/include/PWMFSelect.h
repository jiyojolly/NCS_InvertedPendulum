#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif
   
void PWM_Select(uint8_T PWM_Divisor, uint8_T PWM_Timer);

#ifdef __cplusplus
}
#endif

